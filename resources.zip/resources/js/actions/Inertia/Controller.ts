import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
const Controller980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/dashboard'
 */
const Controller750aeb224105761400ee952169bd178c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller750aeb224105761400ee952169bd178c.url(options),
    method: 'get',
})

Controller750aeb224105761400ee952169bd178c.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/dashboard'
 */
Controller750aeb224105761400ee952169bd178c.url = (options?: RouteQueryOptions) => {
    return Controller750aeb224105761400ee952169bd178c.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/dashboard'
 */
Controller750aeb224105761400ee952169bd178c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller750aeb224105761400ee952169bd178c.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/dashboard'
 */
Controller750aeb224105761400ee952169bd178c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller750aeb224105761400ee952169bd178c.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/settings/appearance'
 */
const Controllerd4683df8c56989388e64a7233af4e7b7 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerd4683df8c56989388e64a7233af4e7b7.url(options),
    method: 'get',
})

Controllerd4683df8c56989388e64a7233af4e7b7.definition = {
    methods: ["get","head"],
    url: '/admin/settings/appearance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/settings/appearance'
 */
Controllerd4683df8c56989388e64a7233af4e7b7.url = (options?: RouteQueryOptions) => {
    return Controllerd4683df8c56989388e64a7233af4e7b7.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/settings/appearance'
 */
Controllerd4683df8c56989388e64a7233af4e7b7.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerd4683df8c56989388e64a7233af4e7b7.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/settings/appearance'
 */
Controllerd4683df8c56989388e64a7233af4e7b7.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerd4683df8c56989388e64a7233af4e7b7.url(options),
    method: 'head',
})

const Controller = {
    '/': Controller980bb49ee7ae63891f1d891d2fbcf1c9,
    '/admin/dashboard': Controller750aeb224105761400ee952169bd178c,
    '/admin/settings/appearance': Controllerd4683df8c56989388e64a7233af4e7b7,
}

export default Controller