import profile from './profile'
import security from './security'
import password from './password'
import appearance from './appearance'
const settings = {
    profile: Object.assign(profile, profile),
security: Object.assign(security, security),
password: Object.assign(password, password),
appearance: Object.assign(appearance, appearance),
}

export default settings